-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: musicstore
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping events for database 'musicstore'
--

--
-- Dumping routines for database 'musicstore'
--
/*!50003 DROP PROCEDURE IF EXISTS `getalbum_bylanguage` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getalbum_bylanguage`(input_language varchar(20))
BEGIN
DECLARE count int default 0;
SET count = (select distinct Languages_Language_ID  from albums where 
Languages_Language_ID = (select Language_ID from languages where Language_Name = input_language));
IF (count >0) THEN
   BEGIN
	   select a.Album_Name, ar.Name  from albums a
	   inner join artists ar on ar.Artist_ID = a.Artists_Artist_ID
	   where Languages_Language_ID = count;
   END;
ELSE
   BEGIN
   select 'No albums available in the provided language.' AS Message;
	-- SIGNAL SQLSTATE '22003'
	-- SET MESSAGE_TEXT =  'Please enter a valid language', 
	-- MYSQL_ERRNO = 1264;
   END;
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Order_Cancellation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Order_Cancellation`(ordernumber INT)
BEGIN
DECLARE count INT default 0;
DECLARE rowcount INT default 0;
DECLARE startcount INT default 1;
DECLARE hasError TINYINT DEFAULT FALSE;
declare alb_id int default 0;
declare quantity int  default 0;
declare Alb_copies int default 0;
declare updated_copies int default 0;

DECLARE CONTINUE HANDLER FOR SQLEXCEPTION 
SET hasError = TRUE;
SET SQL_SAFE_UPDATES = 0;
DROP TEMPORARY TABLE IF EXISTS tmp;
CREATE TEMPORARY TABLE tmp (
  `tmp_ID` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `details_ID` int,
  `Order_ID` int,
  `Album_ID` int,
  `copy` int);
  
INSERT INTO tmp 
SELECT null , Order_details_ID,Orders_Order_ID,Albums_Album_ID, Copies FROM order_details WHERE Orders_Order_ID = ordernumber;

SET rowcount = (select count(*) from tmp);
START TRANSACTION;
Update orders set IsCancelled =1 where Order_ID = ordernumber;

WHILE (startcount <= rowcount) 
DO
set alb_id = (select Album_ID  from tmp where tmp_ID = startcount);
set quantity = (select copy from tmp where tmp_ID = startcount);
select Available_Copies into Alb_copies from musicstore.albums where Album_ID = alb_id;
set updated_copies = (Alb_copies + quantity);

update musicstore.albums set Available_Copies = updated_copies where Album_ID = alb_id;
SET startcount = startcount +1;

END WHILE;

DELETE FROM order_details WHERE Orders_Order_ID = ordernumber;

IF hasError = FALSE THEN
COMMIT;
ELSE
ROLLBACK;
END IF;
DROP TEMPORARY TABLE IF EXISTS tmp;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-19 17:31:04
