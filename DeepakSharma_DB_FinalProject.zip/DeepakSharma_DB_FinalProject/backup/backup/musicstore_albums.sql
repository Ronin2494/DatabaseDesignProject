-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: musicstore
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `albums`
--

DROP TABLE IF EXISTS `albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `albums` (
  `Album_ID` int NOT NULL AUTO_INCREMENT,
  `Album_Name` varchar(200) NOT NULL,
  `Artists_Artist_ID` int NOT NULL,
  `Languages_Language_ID` int NOT NULL,
  `Category_Category_ID` int NOT NULL,
  `Available_Copies` int NOT NULL DEFAULT '0',
  `Price` decimal(9,2) NOT NULL,
  `Created_Datetime` datetime NOT NULL,
  `Modified_Datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Album_ID`),
  KEY `fk_Albums_Artists1_idx` (`Artists_Artist_ID`),
  KEY `fk_Albums_Languages1_idx` (`Languages_Language_ID`),
  KEY `fk_Albums_Category1_idx` (`Category_Category_ID`),
  CONSTRAINT `fk_Albums_Artists1` FOREIGN KEY (`Artists_Artist_ID`) REFERENCES `artists` (`Artist_ID`),
  CONSTRAINT `fk_Albums_Category1` FOREIGN KEY (`Category_Category_ID`) REFERENCES `category` (`Category_ID`),
  CONSTRAINT `fk_Albums_Languages1` FOREIGN KEY (`Languages_Language_ID`) REFERENCES `languages` (`Language_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albums`
--

LOCK TABLES `albums` WRITE;
/*!40000 ALTER TABLE `albums` DISABLE KEYS */;
INSERT INTO `albums` VALUES (1,'Born to Run',2,1,5,170,66.40,'2020-04-11 09:40:28','2020-04-11 09:40:28'),(2,'Toys in the Attic',3,2,4,195,51.09,'2020-04-11 09:40:28','2020-04-11 09:40:28'),(3,'Get a Grip',3,2,3,152,34.50,'2020-04-11 09:40:28','2020-04-11 09:40:28'),(4,'Guilty',4,3,3,189,77.45,'2020-04-11 09:40:28','2020-04-11 09:40:28'),(5,'Hotel California',6,4,2,189,89.90,'2020-04-11 09:40:28','2020-04-11 09:40:28'),(6,'His Hand in Mine',7,5,1,199,45.00,'2020-04-11 09:40:28','2020-04-11 09:40:28'),(7,'Gori Teri Aankhen Kahen',9,5,1,183,85.90,'2020-04-11 09:40:28','2020-04-11 09:40:28'),(8,'Madame X',1,6,2,198,130.00,'2020-04-11 09:40:28','2020-04-11 09:40:28'),(9,'Sifar',9,7,5,198,28.22,'2020-04-11 09:40:28','2020-04-11 09:40:28'),(10,'Invincible',5,10,4,196,50.50,'2020-04-11 09:40:28','2020-04-11 09:40:28'),(11,'Invincible',5,7,4,200,56.00,'2020-04-11 09:40:28','2020-04-11 09:40:28');
/*!40000 ALTER TABLE `albums` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-19 17:31:03
