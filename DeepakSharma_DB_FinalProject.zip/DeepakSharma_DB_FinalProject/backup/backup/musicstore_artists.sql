-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: musicstore
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artists`
--

DROP TABLE IF EXISTS `artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artists` (
  `Artist_ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(45) NOT NULL,
  `Description` longtext,
  `Created_Datetime` datetime NOT NULL,
  `Modified_Datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Artist_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artists`
--

LOCK TABLES `artists` WRITE;
/*!40000 ALTER TABLE `artists` DISABLE KEYS */;
INSERT INTO `artists` VALUES (1,'Madonna','She isn’t called the Queen of Pop for nothing! Madonna Ciccone has been a mainstay in popular music – and had a huge influence on popular culture – since the early 1980s.','2020-04-11 09:40:28','2020-04-11 09:40:28'),(2,'Bruce Springsteen','The Boss is loved in America because he has created albums that find pleasure in daily American life.','2020-04-11 09:40:28','2020-04-11 09:40:28'),(3,'Aerosmith','Long-haired rockers Aerosmith began their musical journey in 1972 when they were signed to Columbia Records. By 1979, they had already recorded and released five albums; they solidified their status as superstars in the hard rock realm. ','2020-04-11 09:40:28','2020-04-11 09:40:28'),(4,'Barbra Streisand','Barbra Streisand is a household name across music, acting and filmmaking. She was singing in clubs and had graced Broadway before releasing her debut album, The Barbra Streisand Album in 1963. ','2020-04-11 09:40:28','2020-04-11 09:40:28'),(5,'Michael Jackson','Michael Jackson is arguably one of the greatest performers of all time, but he hasn’t quite topped the list for selling the most albums. ','2020-04-11 09:40:28','2020-04-11 09:40:28'),(6,'Eagles','With five American Music Awards, six Grammy Awards and six number one albums, the Eagles were one of the most successful acts in the 1970s. ','2020-04-11 09:40:28','2020-04-11 09:40:28'),(7,'Elvis Presley','The King changed music and culture in an unprecedented way in the 1950s. Elvis Presley is seen as the catalyst for the cultural phenomenon of rock and roll, helping to merge the styles of white country and black rhythm and blues music.','2020-04-11 09:40:28','2020-04-11 09:40:28'),(8,'Daler Mehndi','Daler Singh (born 18 August 1967), better known as Daler Mehndi, is an Indian singer, songwriter, author and record producer. He has helped to make Bhangra popular worldwide','2020-04-11 09:40:28','2020-04-11 09:40:28'),(9,'Lucky Ali	','Maqsood Mehmood Ali (born 19 September 1958), better known as Lucky Ali, is an Indian singer-songwriter, composer and actor.','2020-04-11 09:40:28','2020-04-11 09:40:28'),(10,'Haifa Wehbe','Haifa Wehbe (Arabic: هيفاء وهبي) was born March 10th, 1970 in Mahrouna, a small farming town in Southern Lebanon.','2020-04-11 09:40:28','2020-04-11 09:40:28');
/*!40000 ALTER TABLE `artists` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-19 17:31:03
