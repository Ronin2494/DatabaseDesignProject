-- 1.	Display a list of clients that spent more than the average spent by client in the past month.

SELECT c.First_Name, c.Last_Name, sum(o.Amount) 'Amount'  FROM customers c
INNER JOIN orders o ON o.Customers_Customer_ID = c.Customer_ID
WHERE MONTH(o.Order_Date) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH)
GROUP BY o.Customers_Customer_ID
HAVING sum(o.Amount) >= 
(SELECT avg(Amount) FROM orders WHERE 
MONTH(Order_Date) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH));

-- 2.	The top sold products and least sold products over a week.
SELECT Album,Sale FROM 
(SELECT concat(a.Album_Name, ' (Max Sold)') as 'Album' ,sum(Copies) as 'Sale' FROM order_details o
INNER JOIN albums a ON a.Album_ID = o.Albums_Album_ID
INNER JOIN orders oo ON oo.Order_ID = o.Orders_Order_ID
WHERE date(oo.Order_Date) > Week(NOW()) - 1 
GROUP BY Albums_Album_ID ORDER BY 2 DESC LIMIT 1) sale
UNION 
SELECT Album,Sale FROM 
(SELECT concat(a.Album_Name, ' (Min Sold)') as 'Album' ,sum(Copies) as 'Sale' FROM order_details o
INNER JOIN albums a ON a.Album_ID = o.Albums_Album_ID 
INNER JOIN orders oo ON oo.Order_ID = o.Orders_Order_ID
WHERE date(oo.Order_Date) > Week(NOW()) - 1 
GROUP BY Albums_Album_ID ORDER BY 2 ASC LIMIT 1) sale;

-- 2 Alternate - in case of multiple minimum or maximum available
SELECT Album,Sale FROM 
(SELECT concat(a.Album_Name, ' (Min Sold)') as 'Album' ,sum(Copies) as 'Sale' FROM order_details o
INNER JOIN albums a ON a.Album_ID = o.Albums_Album_ID 
INNER JOIN orders oo ON oo.Order_ID = o.Orders_Order_ID
WHERE date(oo.Order_Date) > Week(NOW()) - 1 
GROUP BY Albums_Album_ID having sum(Copies) = 

(SELECT Sum(Copies) FROM order_details o
INNER JOIN albums a ON a.Album_ID = o.Albums_Album_ID 
INNER JOIN orders oo ON oo.Order_ID = o.Orders_Order_ID
WHERE date(oo.Order_Date) > Week(NOW()) - 1 
GROUP BY Albums_Album_ID order by sum(Copies) DESC LIMIT 1) ORDER BY 2) sale
UNION
SELECT Album,Sale FROM 
(SELECT concat(a.Album_Name, ' (Min Sold)') as 'Album' ,sum(Copies) as 'Sale' FROM order_details o
INNER JOIN albums a ON a.Album_ID = o.Albums_Album_ID 
INNER JOIN orders oo ON oo.Order_ID = o.Orders_Order_ID
WHERE date(oo.Order_Date) > Week(NOW()) - 1 
GROUP BY Albums_Album_ID having sum(Copies) = (SELECT Sum(Copies) FROM order_details o
INNER JOIN albums a ON a.Album_ID = o.Albums_Album_ID 
INNER JOIN orders oo ON oo.Order_ID = o.Orders_Order_ID
WHERE date(oo.Order_Date) > Week(NOW()) - 1 
GROUP BY Albums_Album_ID order by sum(Copies) ASC LIMIT 1) ORDER BY 2) sale;

-- 3.	The maximum price of products in the same category (for example, rock, pop, country, hip-hop). Use group by to list all the categories and their maximum price.
SELECT c.Category_Name, max(Price) AS Max_Price FROM musicstore.albums a
INNER JOIN category c ON a.Category_Category_ID = c.Category_ID
GROUP BY a.Category_Category_ID;


-- 4.	List how many customers the system has by location (Country, Province, and City), and then sort them.
SELECT Country, Province, City, count(1) AS Customer_Count 
FROM musicstore.customer_address WHERE IsActive=1
-- and Country = 'canada'
GROUP BY Country, Province, City 
ORDER BY Customer_Count DESC;

-- 5.	List how many products the store has sold for a particular month.
SELECT MONTHNAME(o.Order_Date) As Order_Month, sum(Copies) As Sale_Quantity 
FROM musicstore.order_details od
INNER JOIN orders o ON o.Order_ID = od.Orders_Order_ID
GROUP BY Order_Month order by MONTH(o.Order_Date);

-- 6.	List how many distinct albums each singer has.
SELECT ar.Name, count(distinct a.Album_Name) 'No of Distinct Albums' 
FROM musicstore.albums a
INNER JOIN artists ar ON ar.Artist_ID = a.Artists_Artist_ID
GROUP BY a.Artists_Artist_ID;

-- 7.	List how many copies of an album are available of a particular singer.
SELECT ar.Name 'Artist',a.Album_Name,a.Available_Copies 'Available_Copies' 
FROM musicstore.albums a
INNER JOIN artists ar ON ar.Artist_ID = a.Artists_Artist_ID
GROUP BY a.Artists_Artist_ID, a.Album_ID;


-- GROUP -8 SPECIFIC SCENARIOS

 -- Q1: Filter albums according to language.
-- Pass any language name as desired.
CALL getalbum_bylanguage('spanish');


-- Q2: The most popular album according to the language.
SELECT * FROM 
(SELECT l.Language_Name 'Language' ,a.Album_Name, sum(od.Copies) 'Max_Sold'
FROM musicstore.albums a
INNER JOIN languages l ON l.Language_ID = a.Languages_Language_ID
INNER JOIN order_details od ON od.Albums_Album_ID = a.Album_ID
GROUP BY a.Languages_Language_ID, od.Albums_Album_ID 
ORDER BY Max_Sold DESC
) t1
GROUP BY Language;
